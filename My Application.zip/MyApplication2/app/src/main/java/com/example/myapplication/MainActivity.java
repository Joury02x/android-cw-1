package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText x1 = findViewById(R.id.Quizzes);
        EditText x2 = findViewById(R.id.Homework);
        EditText x3 = findViewById(R.id.MedTerms);
        EditText x4 = findViewById(R.id.Final);
        Button calculate = findViewById(R.id.button);



        Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        })
        

    }

}